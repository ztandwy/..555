import json,math,random,subprocess,pathlib,wave
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
P=pathlib.Path('/workspace/history-video'); W,H=1280,720; FPS=24
scenes=json.load(open(P/'timeline.json'))
serif='/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
sans='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
fonts={k:ImageFont.truetype(serif if k>=38 else sans,k) for k in [16,20,24,28,32,38,46,54,66]}
gold=(230,186,101); white=(238,230,210); muted=(149,137,114)
rng=np.random.default_rng(4)
y,x=np.mgrid[0:H,0:W]; v=np.maximum(0,1-((x-650)**2/(800**2)+(y-360)**2/(550**2)))
n=rng.normal(0,1.8,(H,W))
bg=np.stack([15+v*17+n,16+v*12+n,18+v*5+n],axis=-1).clip(0,255).astype('uint8'); base=Image.fromarray(bg)
d=ImageDraw.Draw(base)
random.seed(9)
for j in range(40):
 cx=random.randint(-200,1400);cy=random.randint(100,800);rx=random.randint(160,420);ry=random.randint(30,110)
 pts=[(cx+rx*math.cos(t)*(1+.13*math.sin(t*5+j)),cy+ry*math.sin(t)*(1+.2*math.cos(t*4))) for t in np.linspace(0,2*math.pi,100)]
 d.line(pts,fill=(44,40,31),width=1)

def text(d,xy,s,size=28,col=white,anchor=None):d.text(xy,s,font=fonts[size],fill=col,anchor=anchor)
def line(d,pts,col=gold,w=3):d.line(pts,fill=col,width=w)
def weight(d,cx,cy,scale=1,inscription=False):
 def pts(ps):return [(cx+a*scale,cy+b*scale) for a,b in ps]
 d.ellipse((cx-38*scale,cy-125*scale,cx+38*scale,cy-52*scale),outline=gold,width=max(2,int(5*scale)))
 d.polygon(pts([(-85,-40),(85,-40),(135,95),(-135,95)]),fill=(113,84,45),outline=gold,width=3)
 d.polygon(pts([(-85,-40),(85,-40),(106,-14),(-105,-14)]),fill=(173,127,64))
 d.polygon(pts([(85,-40),(135,95),(106,113),(106,-14)]),fill=(65,51,32),outline=(153,120,62))
 line(d,pts([(-135,95),(106,95),(106,113),(-122,113),(-135,95)]),(167,124,62),2)
 if inscription:
  for k,ss in enumerate(['廿六年','皇帝盡并','法度量則','皆明壹之']):text(d,(cx,cy-3+k*24*scale),ss,20,gold,'mm')

def vessel(d,cx,cy,sc=1):
 d.rectangle((cx-60*sc,cy-40*sc,cx+60*sc,cy+65*sc),fill=(107,79,42),outline=gold,width=3)
 d.ellipse((cx-60*sc,cy-60*sc,cx+60*sc,cy-22*sc),fill=(44,37,26),outline=gold,width=3)
 d.arc((cx+30*sc,cy-15*sc,cx+100*sc,cy+45*sc),-90,90,fill=gold,width=4)

def arrow(d,a,b):
 line(d,[a,b]);ang=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-15*math.cos(ang-.45),b[1]-15*math.sin(ang-.45)),(b[0]-15*math.cos(ang+.45),b[1]-15*math.sin(ang+.45))],fill=gold)

def diagram(d,s,i,t):
 k=s['kind']; cy=385
 if k=='weight':
  weight(d,640,cy,1.4,True)
  text(d,(340,cy-70),'秦 权',38,gold,'mm');text(d,(930,cy-60),'诏书铭文',38,gold,'mm')
  line(d,[(795,cy),(870,cy),(900,cy-30)])
  text(d,(640,580),'器物造型为示意',16,muted,'mm')
 elif k=='scales':
  for j,sc in enumerate([.8,1.15,1.45]):
   cx=300+j*340;vessel(d,cx,cy,sc);text(d,(cx,cy-130),'同名“一升”',28,gold,'mm');text(d,(cx,cy+150),['标准 A','标准 B','标准 C'][j],24,white,'mm')
  text(d,(640,590),'容量对比为概念示意，不代表具体出土器物尺寸',16,muted,'mm')
 elif k=='network':
  nodes=[(290,320),(340,480),(820,300),(990,460)];center=(640,400)
  for j,(cx,yy) in enumerate(nodes):
   line(d,[center,(cx,yy)],(111,89,50),3)
   d.rounded_rectangle((cx-80,yy-35,cx+80,yy+35),radius=8,fill=(33,31,26),outline=(132,105,61),width=2)
   text(d,(cx,yy),['交易','征税','仓储','各地'][j],28,white,'mm')
   u=(t*.18+j*.23)%1;px=center[0]+(cx-center[0])*u;py=center[1]+(yy-center[1])*u;d.ellipse((px-5,py-5,px+5,py+5),fill=gold)
  d.ellipse((560,320,720,480),fill=(82,63,33),outline=gold,width=3);text(d,(640,400),'共同标准' if i==6 else '度量衡',28,gold,'mm')
 elif k=='units':
  for j,ss in enumerate(['度','量','衡']):
   cx=285+j*355;text(d,(cx,280),ss,66,gold,'mm');text(d,(cx,555),['长度','容量','重量'][j],32,white,'mm')
   if j==0:
    d.rectangle((cx-115,375,cx+115,415),fill=(105,79,42),outline=gold,width=2)
    for q in range(16):line(d,[(cx-108+q*14,377),(cx-108+q*14,390+(q%5==0)*14)],gold,2)
   elif j==1:vessel(d,cx,390,1.05)
   else:weight(d,cx,385,.78)
 elif k=='edict':
  d.rounded_rectangle((170,240,1110,530),radius=12,fill=(39,34,25),outline=(161,122,60),width=2)
  text(d,(640,295),'秦始皇二十六年诏书铭文（节选）',24,muted,'mm')
  text(d,(640,380),'法度量则不壹歉疑者',46,gold,'mm');text(d,(640,460),'皆明壹之',54,gold,'mm')
  text(d,(640,577),'以传世及出土秦权、秦量铭文为依据',20,muted,'mm')
 elif k=='merge':
  for j in range(3):
   cx=280;yy=290+j*90;line(d,[(cx-70,yy),(cx+40+j*30,yy)],white,5);arrow(d,(cx+150,yy),(740,385))
  d.rounded_rectangle((770,315,1040,455),radius=12,fill=(87,66,32),outline=gold,width=3)
  text(d,(905,385),'明确统一',38,gold,'mm');text(d,(640,570),'从制度命令，到器物上的记录',24,muted,'mm')

def frame(i,t,duration):
 s=scenes[i];im=base.copy();d=ImageDraw.Draw(im)
 text(d,(58,35),'器物里的历史',20,gold);text(d,(1220,35),f'{i+1:02d} / 08',20,muted,'ra')
 line(d,[(58,70),(1222,70)],(79,66,43),1)
 text(d,(64,103),s['title'],46,white);text(d,(66,172),s['sub'],24,gold)
 diagram(d,s,i,t)
 # Animated emphasis follows the explanation within each scene.
 progress=min(1,max(0,(t-.4)/(duration-1)))
 if s['kind']=='edict':
  line(d,[(390,418),(390+int(500*progress),418)],gold,2)
 elif s['kind']=='units':
  cx=[285,640,995][min(2,int(t/duration*3))]
  d.arc((cx-137,245,cx+137,580),200,200+int(300*progress),fill=gold,width=2)
 elif s['kind']=='weight':
  px=795+105*progress; py=385-30*progress
  d.ellipse((px-4,py-4,px+4,py+4),fill=gold)
 elif s['kind']=='merge':
  for j in range(3):
   u=(t*.25+j*.24)%1; px=430+310*u;py=(290+j*90)+(385-(290+j*90))*u
   d.ellipse((px-5,py-5,px+5,py+5),fill=gold)
 elif s['kind']=='scales':
  cx=300+340*min(2,int(t/duration*3));line(d,[(cx-95,570),(cx+95,570)],gold,2)
 ci=min(2,int(t/max(.01,duration)*3));cap=s['captions'][ci]
 d.rounded_rectangle((145,615,1135,679),radius=12,fill=(9,11,13),outline=(67,57,39))
 text(d,(640,647),cap,32,white,'mm')
 text(d,(60,686),'史料：《史记·秦始皇本纪》；秦始皇二十六年诏书铭文',16,muted)
 text(d,(1220,686),'原创示意动画 · 合成旁白',16,muted,'ra')
 line(d,[(0,718),(int(W*(i+t/duration)/8),718)],gold,3)
 fade=min(1,t/.35,(duration-t)/.35)
 if fade<1:im=Image.blend(Image.new('RGB',(W,H),(12,13,15)),im,max(0,fade))
 return im

# Render each narrated scene and burn captions into the video.
for i,s in enumerate(scenes):
 dur=s['duration'];count=math.ceil(dur*FPS)
 out=P/f'scene{i}.mp4'
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-i',str(P/f'voice{i}.wav'),'-af','apad','-t',str(count/FPS),'-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-threads','4',str(out)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for f in range(count):proc.stdin.write(frame(i,f/FPS,count/FPS).tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('encode failed')
 frame(i,2,dur).save(P/f'preview{i}.jpg')
 print('rendered',i,round(dur,2),flush=True)
(P/'concat.txt').write_text('\n'.join(f"file '{P/f'scene{i}.mp4'}'" for i in range(len(scenes))))
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(P/'concat.txt'),'-c','copy','-movflags','+faststart',str(P/'秦始皇为什么把诏书刻在秤砣上.mp4')],check=True)
print('DONE',sum(s['duration'] for s in scenes),flush=True)
