import json, pathlib, sherpa_onnx, soundfile as sf
p=pathlib.Path('/tmp/vits-zh-aishell3')
print([x.name for x in p.iterdir()],flush=True)
c=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(p/'vits-aishell3.onnx'),lexicon=str(p/'lexicon.txt'),tokens=str(p/'tokens.txt')),num_threads=4,provider='cpu'),rule_fsts=','.join(str(x) for x in p.glob('*.fst')))
print('config valid',c.validate(),flush=True)
t=sherpa_onnx.OfflineTts(c)
scenes=json.load(open('/workspace/history-video/scenes.json'))
for i,s in enumerate(scenes):
 a=t.generate(s['voice'],sid=10,speed=1.18)
 sf.write(f'/workspace/history-video/voice{i}.wav',a.samples,a.sample_rate)
 s['duration']=len(a.samples)/a.sample_rate+0.5
 print(i,s['duration'],flush=True)
json.dump(scenes,open('/workspace/history-video/timeline.json','w'),ensure_ascii=False,indent=2)
