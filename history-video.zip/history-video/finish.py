import pathlib,json,math,subprocess
import numpy as np
import soundfile as sf
P=pathlib.Path('/workspace/history-video');ss=json.load(open(P/'timeline.json'))
duration=sum(math.ceil(s['duration']*24)/24 for s in ss)
sr=44100;t=np.arange(int((duration+.5)*sr))/sr;a=np.zeros_like(t)
# An original, restrained pentatonic underscore.
for j in range(int(duration/2.4)+1):
 start=j*2.4;freq=[146.83,174.61,196,220,261.63,220,196,174.61][j%8]
 z=t-start;mask=(z>=0)&(z<7);q=z[mask];env=(1-np.exp(-q*14))*np.exp(-q/1.5)
 a[mask]+=.026*env*(np.sin(2*np.pi*freq*q)+.25*np.sin(2*np.pi*2*freq*q))
a*=np.clip(t/1.5,0,1)*np.clip((duration-t)/2,0,1)
sf.write(P/'原创氛围配乐.wav',np.stack([a,a*.95],axis=1),sr)
subtitle=[];pos=0;n=1
fmt=lambda sec:f'{int(sec//3600):02d}:{int(sec%3600//60):02d}:{int(sec%60):02d},{int(sec%1*1000):03d}'
for s in ss:
 dur=math.ceil(s['duration']*24)/24
 for j,c in enumerate(s['captions']):
  subtitle.append(f'{n}\n{fmt(pos+dur*j/3)} --> {fmt(pos+dur*(j+1)/3)}\n{c}\n');n+=1
 pos+=dur
(P/'字幕.srt').write_text('\n'.join(subtitle))
(P/'文案与史料说明.md').write_text('# 秦始皇为什么把诏书刻在秤砣上\n\n约59秒，16:9横屏。原创示意动画、本地合成中文旁白、原创合成氛围配乐。\n\n'+ '\n\n'.join(f'镜头{i+1}：{s["title"]}\n\n{s["voice"]}' for i,s in enumerate(ss))+'\n\n史料依据：\n\n- 《史记》卷六《秦始皇本纪》：“一法度衡石丈尺。车同轨。书同文字。”\n- 秦始皇二十六年诏书铭文，见带诏书铭文的秦权、秦量：“法度量则不壹歉疑者，皆明壹之。”铭文转写在不同整理资料中可能采用不同的通假字标写。\n\n图中秦权、秦量、尺寸对比及连线均为概念示意，不按某件出土文物复原；A/B/C为解释标准差异所设的标签，并非具体国家、实际容量或实测比例。统一标准为政策推行，未断言其在全国即时完成。\n')
for i in range(8):
 info=sf.info(P/f'voice{i}.wav');samples,_=sf.read(P/f'voice{i}.wav');print('voice',i,'seconds',round(info.duration,2),'peak',round(float(abs(samples).max()),3))
